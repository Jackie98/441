## Week 5 Homework Readme Document
Jacqueline Evans-Shaw

# Work Process
---
This week's work process went by much more smoothly! I really appreciated the tutorial video, as it helped me follow the steps exactly--and since I'm a visual and hands-on learner, this cemented a lot of the coding concepts for me that I had previously learned but not fully understood.
I was also able to check in with classmates to ensure that my code was functional and that everything was being displayed properly and that I understood the concepts.
We each had a lot of fun designing our games.

# Issues
---
I only experienced a minor issue of my images not showing up because I named them incorrectly! A good lesson in attention to detail.

# Successes
---
I originall learned about arrays in Coding 101, but truthfully, the practice of using them didn't stick well with me and I avoided them. After this assignment, I feel I was successful in grasping the concept of their usefulness and successfully applied it to my own work, which made me feel like I was actually competent with coding! Thanks a lot for the great tutorial videos, and thanks for reading!
